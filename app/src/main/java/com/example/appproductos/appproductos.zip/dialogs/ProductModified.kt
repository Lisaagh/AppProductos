package com.example.appproductos.dialogs

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun ProductModifiedDialog(
    title: String = "Product Modified",
    message: String = "The product has been successfully modified.",
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = {
            Text(text = title)
        },
        text = {
            Text(text = message)
        },
        confirmButton = {
            TextButton(
                onClick = { onDismiss() }
            ) {
                Text("OK")
            }
        }
    )
}
