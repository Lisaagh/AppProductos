package com.example.appproductos.dialogs

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun ProductAddedDialog(
    title: String = "Product Added",
    message: String = "The product has been successfully added.",
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = {
            Text(text = title)
        },
        text = {
            Text(text = message)
        },
        confirmButton = {
            TextButton(
                onClick = { onDismiss() }
            ) {
                Text("OK")
            }
        }
    )
}