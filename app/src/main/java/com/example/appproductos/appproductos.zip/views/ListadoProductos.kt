package com.example.appproductos.views

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LiveData
import com.example.appproductos.model.Producto
import com.example.appproductos.viewmodels.ProductoViewModel
import com.example.appproductos.dialogs.ConfirmDeleteDialog
import com.example.appproductos.ui.theme.onTertiaryContainerLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListadoProductos(
    productos: LiveData<List<Producto>>,
    onNavigateToInicio: () -> Unit,
    onNavigateToRegistro: () -> Unit,
    onNavigateToEdit: (Producto) -> Unit,
    viewModel: ProductoViewModel
) {
    val productosList by productos.observeAsState(emptyList())

    var showDialog by remember { mutableStateOf(false) }
    var productoToDelete by remember { mutableStateOf<Producto?>(null) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Listado de Productos", color = MaterialTheme.colorScheme.tertiary) // Color del texto del título
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { onNavigateToInicio() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Regresar")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer) // Color del fondo del TopAppBar
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (productosList.isEmpty()) {
                    Text("No hay productos disponibles.", fontSize = 20.sp)
                } else {
                    productosList.forEach { producto ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .shadow(4.dp, shape = MaterialTheme.shapes.small),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.onSecondaryContainer) // Color de fondo del Card
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(text = "${producto.Nombre}", fontSize = 18.sp, color = MaterialTheme.colorScheme.onTertiaryContainer) // Color del nombre
                                Text(text = "Descripción: ${producto.Descripcion}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface) // Color de la descripción
                                Text(text = "Precio: ${producto.Precio}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onErrorContainer) // Color del precio
                                Text(text = "Fecha de Registro: ${producto.FechaRegistro}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground) // Color de la fecha

                                Row(
                                    modifier = Modifier.align(Alignment.End),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onNavigateToEdit(producto) },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onTertiaryContainer)
                                    ) {
                                        Text("Editar", color = MaterialTheme.colorScheme.onPrimary)
                                    }

                                    Button(
                                        onClick = {
                                            productoToDelete = producto
                                            showDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                    ) {
                                        Text("Eliminar", color = MaterialTheme.colorScheme.tertiary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Button(
                onClick = { onNavigateToRegistro() },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onTertiaryContainer) // Color del botón de registrar
            ) {
                Text("Registrar", color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    }

    // Mostrar el diálogo de confirmación si se activa
    if (showDialog && productoToDelete != null) {
        ConfirmDeleteDialog(
            onConfirm = {
                viewModel.eliminarProducto(productoToDelete!!)
                showDialog = false
                productoToDelete = null
            },
            onCancel = {
                showDialog = false
                productoToDelete = null
            }
        )
    }
}
