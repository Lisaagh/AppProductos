package com.example.appproductos.views

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.appproductos.model.Producto
import com.example.appproductos.viewmodels.ProductoViewModel
import com.example.appproductos.dialogs.ProductModifiedDialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditarProducto(
    producto: Producto,
    onNavigateBack: () -> Unit,
    viewModel: ProductoViewModel
) {
    var nombre by remember { mutableStateOf(producto.Nombre) }
    var descripcion by remember { mutableStateOf(producto.Descripcion) }
    var precio by remember { mutableStateOf(producto.Precio.toString()) }
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Editar Producto", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { onNavigateBack() }) {
                        Icon(
                            Icons.Default.ArrowBack, contentDescription = "Regresar",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // TextField para Nombre
            TextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre") },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    focusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    unfocusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    cursorColor = MaterialTheme.colorScheme.inverseSurface
                )
            )
            // TextField para Descripción
            TextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción") },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    focusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    unfocusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    cursorColor = MaterialTheme.colorScheme.inverseSurface
                )
            )
            // TextField para Precio
            TextField(
                value = precio,
                onValueChange = { precio = it },
                label = { Text("Precio") },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    unfocusedContainerColor = MaterialTheme.colorScheme.inversePrimary,
                    focusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    unfocusedIndicatorColor = MaterialTheme.colorScheme.inverseSurface,
                    cursorColor = MaterialTheme.colorScheme.inverseSurface
                )
            )
            // Botón para guardar cambios
            Button(
                onClick = {
                    viewModel.editarProducto(
                        producto.copy(Nombre = nombre, Descripcion = descripcion, Precio = precio.toDouble())
                    )
                    showDialog = true
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.onTertiaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text("Guardar Cambios")
            }
        }
    }

    // Mostrar el diálogo de información después de editar
    if (showDialog) {
        ProductModifiedDialog(
            onDismiss = {
                showDialog = false
                onNavigateBack()
            }
        )
    }
}
